// exmaotarc.cpp, v1.06.1 2013/09/08
// coded by asmodean

// contact: 
//   web:   http://asmodean.reverse.net
//   email: asmodean [at] hush.com
//   irc:   asmodean on efnet (irc.efnet.net)

// This tool extracts TACTICS_ARC_FILE (*.arc) archives used
// by �����̂����ɐ��C�L�����I and others.

#include "as-util.h"
#include "as-lzss.h"

// Uses standard LZSS
// #define VERSION 1

// Uses a LZ variation with variable length numerics
#define VERSION 2

struct ARCHDR {
  uint8_t signature[16]; // "TACTICS_ARC_FILE"
};

struct ARCENTRY {
  uint32_t length;
  uint32_t original_length;
  uint32_t filename_length;
  uint8_t  unknown[8]; // hash probably
  // char  filename[filename_length];
};

struct game_info_t {
  string name;
  string key;
};

#if VERSION >= 2
static const std::array<game_info_t, 2> GAME_INFO = {{ 
  { "�A�N�}�ŃI�V�I�L���I �ۏ�˃T�h���w���^�C���d�u���u��", "RuPMqG64" },
  { "�C�m�Z���g�o���b�g -the false world-", "t92kgvKo" },
}};    
#else
static const std::array<game_info_t, 4> GAME_INFO = {{ 
  { "�����̂����ɐ��C�L�����I", "Puni0r4p" },
  { "�����ς�I�V����Ɓm�Ձn �`���Ɨ��͑�]�˂̉؁`", "JyEeJxwQ" },
  { "������!! ���Ԓ�", "Klw79n6f" },
  { "���t���b ALICETALE", "zv7jpFTV" },
}};
#endif

static const auto GAME_CHOICES = as::choices_by_index_t<game_info_t>::init(GAME_INFO);

void unobfuscate(uint8_t*      buff,
                 uint32_t      len,
                 const string& key)
{
  auto     key_buff = (uint8_t*) key.c_str();
  uint32_t key_len  = key.length();

  auto end = buff + len;

  for (uint32_t i = 0; i < len; i++) {
    buff[i] ^= key[i % key_len];
  }
}

bool guess_key(const string& filename, string& key) {
  static const uint8_t MATCH[] = "log.txt";

  int      fd   =  as::open_or_die(filename, O_RDONLY | O_BINARY);
  uint32_t len  = as::get_file_size(fd);
  uint8_t* buff = new uint8_t[len];
  read(fd, buff, len);
  close(fd);

  bool found = false;

  auto end = buff + len;

  for (auto p = buff; p + sizeof(MATCH) < end; p++) {
    if (!memcmp(p, MATCH, sizeof(MATCH))) {
      p += sizeof(MATCH);
      
      while (!*p) p++;

      key   = (char*)p;
      found = true;
      break;
    }
  }

  delete [] buff;

  return found;
}

void unlz_variable(uint8_t* buff,
                   uint32_t len,
                   uint8_t* out_buff,
                   uint32_t out_len)
{
  static const uint16_t BACKREF_TABLE[] = {
    0x0001, 0x0804, 0x1001, 0x2001, 0x0002, 0x0805, 0x1002, 0x2002, 
    0x0003, 0x0806, 0x1003, 0x2003, 0x0004, 0x0807, 0x1004, 0x2004, 
    0x0005, 0x0808, 0x1005, 0x2005, 0x0006, 0x0809, 0x1006, 0x2006, 
    0x0007, 0x080A, 0x1007, 0x2007, 0x0008, 0x080B, 0x1008, 0x2008, 
    0x0009, 0x0904, 0x1009, 0x2009, 0x000A, 0x0905, 0x100A, 0x200A, 
    0x000B, 0x0906, 0x100B, 0x200B, 0x000C, 0x0907, 0x100C, 0x200C, 
    0x000D, 0x0908, 0x100D, 0x200D, 0x000E, 0x0909, 0x100E, 0x200E, 
    0x000F, 0x090A, 0x100F, 0x200F, 0x0010, 0x090B, 0x1010, 0x2010, 
    0x0011, 0x0A04, 0x1011, 0x2011, 0x0012, 0x0A05, 0x1012, 0x2012, 
    0x0013, 0x0A06, 0x1013, 0x2013, 0x0014, 0x0A07, 0x1014, 0x2014, 
    0x0015, 0x0A08, 0x1015, 0x2015, 0x0016, 0x0A09, 0x1016, 0x2016, 
    0x0017, 0x0A0A, 0x1017, 0x2017, 0x0018, 0x0A0B, 0x1018, 0x2018, 
    0x0019, 0x0B04, 0x1019, 0x2019, 0x001A, 0x0B05, 0x101A, 0x201A, 
    0x001B, 0x0B06, 0x101B, 0x201B, 0x001C, 0x0B07, 0x101C, 0x201C, 
    0x001D, 0x0B08, 0x101D, 0x201D, 0x001E, 0x0B09, 0x101E, 0x201E, 
    0x001F, 0x0B0A, 0x101F, 0x201F, 0x0020, 0x0B0B, 0x1020, 0x2020, 
    0x0021, 0x0C04, 0x1021, 0x2021, 0x0022, 0x0C05, 0x1022, 0x2022, 
    0x0023, 0x0C06, 0x1023, 0x2023, 0x0024, 0x0C07, 0x1024, 0x2024, 
    0x0025, 0x0C08, 0x1025, 0x2025, 0x0026, 0x0C09, 0x1026, 0x2026, 
    0x0027, 0x0C0A, 0x1027, 0x2027, 0x0028, 0x0C0B, 0x1028, 0x2028, 
    0x0029, 0x0D04, 0x1029, 0x2029, 0x002A, 0x0D05, 0x102A, 0x202A, 
    0x002B, 0x0D06, 0x102B, 0x202B, 0x002C, 0x0D07, 0x102C, 0x202C, 
    0x002D, 0x0D08, 0x102D, 0x202D, 0x002E, 0x0D09, 0x102E, 0x202E, 
    0x002F, 0x0D0A, 0x102F, 0x202F, 0x0030, 0x0D0B, 0x1030, 0x2030, 
    0x0031, 0x0E04, 0x1031, 0x2031, 0x0032, 0x0E05, 0x1032, 0x2032, 
    0x0033, 0x0E06, 0x1033, 0x2033, 0x0034, 0x0E07, 0x1034, 0x2034, 
    0x0035, 0x0E08, 0x1035, 0x2035, 0x0036, 0x0E09, 0x1036, 0x2036, 
    0x0037, 0x0E0A, 0x1037, 0x2037, 0x0038, 0x0E0B, 0x1038, 0x2038, 
    0x0039, 0x0F04, 0x1039, 0x2039, 0x003A, 0x0F05, 0x103A, 0x203A, 
    0x003B, 0x0F06, 0x103B, 0x203B, 0x003C, 0x0F07, 0x103C, 0x203C, 
    0x0801, 0x0F08, 0x103D, 0x203D, 0x1001, 0x0F09, 0x103E, 0x203E, 
    0x1801, 0x0F0A, 0x103F, 0x203F, 0x2001, 0x0F0B, 0x1040, 0x2040, 
  };

  auto end     = buff + len;
  auto out_end = out_buff + out_len;

  uint32_t out_len2 = 0;

  for (uint32_t i = 0; true; i++) 
  {
    uint8_t c = *buff++;

    out_len2 |= (c & 0x7F) << (i * 7);

    if (!(c & 0x80)) 
    {
      break;
    }
  }

  while (out_buff < out_end) 
  {
    uint8_t c = *buff++;

    if (c & 3) 
    {
      uint32_t extra = BACKREF_TABLE[c] >> 11;

      uint32_t p = 0;
      for (uint32_t i = 0; i < extra; i++) {
        p |= *buff++ << (i * 8);
      }

      p += BACKREF_TABLE[c] & 0x700;

      uint32_t n = BACKREF_TABLE[c] & 0xFF;

      while (n--) {
        *out_buff = *(out_buff - p);
        out_buff++;
      }
    } 
    else 
    {
      uint32_t n = (c >> 2) + 1;

      if (n >= 0x3D) 
      {
        uint32_t extra = n - 0x3C;

        n = 0;
        for (uint32_t i = 0; i < extra; i++) 
        {
          n |= *buff++ << (i * 8);
        }

        n++;        
      }

      while (n--) 
      {
        *out_buff++ = *buff++;
      }
    }
  }
}

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "exmaotarc v1.06.1 by asmodean\n\n");
    fprintf(stderr, "usage: %s <input.arc> <choice|game.exe>\n", argv[0]);
    GAME_CHOICES.print();

    fprintf(stderr, "\n\tchoice = game.exe -> auto\n");

    return -1;
  }

  string in_filename = argv[1];
  string game        = argv[2];

  string key;

  if (as::stringtol(game).find(".exe") != string::npos) 
  {
    if (!guess_key(game, key)) 
    {
      fprintf(stderr, "%s: failed to guess key\n", game.c_str());
      return -1;
    }

    fprintf(stderr, "Using auto key [%s]\n", key.c_str());
  } 
  else 
  {
    key = GAME_CHOICES.get(game).key;
  }

  int fd = as::open_or_die(in_filename, O_RDONLY | O_BINARY);

  ARCHDR hdr;
  read(fd, &hdr, sizeof(hdr));

  ARCENTRY entry;
  while (read(fd, &entry, sizeof(entry)) == sizeof(entry)) 
  {
    if (!entry.length) 
    {
      continue;
    }

    auto filename = new char[entry.filename_length + 1];
    memset(filename, 0, entry.filename_length + 1);
    read(fd, filename, entry.filename_length);

    uint32_t len  = entry.length;
    auto     buff = new uint8_t[len];
    read(fd, buff, len);
    unobfuscate(buff, len, key);

    if (entry.original_length) 
    {
      uint32_t temp_len  = entry.original_length;
      auto     temp_buff = new uint8_t[temp_len];
#if VERSION >= 2
      unlz_variable(buff, len, temp_buff, temp_len);
#else
      as::unlzss(buff, len, temp_buff, temp_len);
#endif

      delete [] buff;

      len  = temp_len;
      buff = temp_buff;
    }

    as::make_path(filename);
    as::write_file(filename, buff, len);

    delete [] buff;
    delete [] filename;
  }

  close(fd);

  return 0;
}
