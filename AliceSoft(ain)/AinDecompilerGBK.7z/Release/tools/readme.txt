Crage and arc_conv are tools separate from this program which handle the encoding and decoding of compressed/encrypted AIN files.
This program calls the tools as needed.

crage is used for version 5 AIN files and earlier (AIN files are encrypted but not compressed)

arc_conv is used for version 6 AIN files and later (AIN files are compressed)
