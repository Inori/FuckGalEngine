// extk2fpk.cpp, v1.1 2013/06/05
// coded by asmodean

// contact: 
//   web:   http://asmodean.reverse.net
//   email: asmodean [at] hush.com
//   irc:   asmodean on efnet (irc.efnet.net)

// This tool decompresses data from *.FPK archives...

#include "as-util.h"

// Version 1 is detected by the header flag.
//#define FPK_VERSION 2
#define FPK_VERSION 3

struct FPKHDR {
  uint32_t entry_count; // flag in the high bit
};

struct FPKTRL {
  uint32_t key;
  uint32_t toc_offset;
};

#if FPK_VERSION >= 3
struct FPKENTRY1 {
  uint32_t offset;
  uint32_t length;
  char     filename[128];
  uint32_t unknown;
};
#else
struct FPKENTRY1 {
  uint32_t offset;
  uint32_t length;
  char     filename[24];
  uint32_t unknown;
};
#endif

struct FPKENTRY2 {
  uint32_t offset;
  uint32_t length;
  char     filename[24];
};

struct ZLC2HDR {
  uint8_t  signature[4]; // "ZLC2"
  uint32_t original_length;
};

struct RLE0HDR {
  uint8_t  signature[4]; // "RLE0"
  uint32_t depth; // ?
  uint32_t length;
  uint32_t original_length;
  uint32_t type;
  uint32_t unknown2;
};

const uint32_t RLE0_TYPE_PLAIN = 0;
const uint32_t RLE0_TYPE_RLE   = 1;

void unrle0(uint8_t*& buff,
            uint32_t& len)
{
  auto p   = buff;
  auto hdr = (RLE0HDR*) p;
  p += sizeof(*hdr);

  if (memcmp(hdr->signature, "RLE0", 4)) {
    return;
  }

  if (hdr->type != RLE0_TYPE_PLAIN &&
      hdr->type != RLE0_TYPE_RLE)
  {
    return;
  }

  uint32_t out_len  = hdr->original_length;
  auto     out_buff = new uint8_t[out_len];

  auto out_p   = out_buff;
  auto out_end = out_buff + out_len;

  switch (hdr->type) {
  case RLE0_TYPE_PLAIN:
    memcpy(out_p, p, out_len);
    break;

  case RLE0_TYPE_RLE:
    while (out_p < out_end) {
      uint8_t  c = *p++;
      uint32_t n = c & 0x3F;
      c >>= 6;

      if (!n) {
        n = 0x40;
      }

      switch (c) {
      case 0:
        while (n--) {
          *out_p++ = *p++;
        }
        break;

      case 1:
      case 2:
      case 3:
        n++;
        while (n--) {
          for (uint32_t i = 0; i < c; i++) {
            *out_p++ = *(p + i);
          }
        }
        p += c;
        break;
      }
    }
  }

  delete [] buff;

  len  = out_len;
  buff = out_buff;
}

void unzlc2(uint8_t*& buff, 
            uint32_t& len)
{
  auto in_p = buff;
  auto hdr  = (ZLC2HDR*) buff;
  in_p += sizeof(*hdr);

  if (memcmp(hdr->signature, "ZLC2", 4)) {
    return;
  }

  uint32_t out_len  = hdr->original_length;
  auto     out_buff = new uint8_t[out_len];

  auto end     = buff + len;
  auto out_p   = out_buff;
  auto out_end = out_buff + out_len;

  while (in_p < end && out_p < out_end) {
    uint8_t flags = *in_p++;

    for (int i = 0; i < 8 && in_p < end && out_p < out_end; i++) {
      if (flags & 0x80) {
        if (end - in_p < 2)
          break;

        uint32_t p = *in_p++;
        uint32_t n = *in_p++;
                                
        p |= (n & 0xF0) << 4;
        n  = (n & 0x0F) + 3;

        if (!p) {
          p = 4096;
        }

        for (uint32_t j = 0; j < n && out_p < out_end; j++) {
          *out_p = *(out_p - p);
          *out_p++;
        }
      } else {
        *out_p++ = *in_p++;
      }

      flags <<= 1;
    }
  }

  delete [] buff;

  len  = out_len;
  buff = out_buff;
}

void unobfuscate(uint8_t* buff,
                 uint32_t len,
                 uint32_t key) 
{
  auto* p   = (uint32_t*) buff;
  auto* end = (uint32_t*) (buff + len);

  while (p < end) {
    *p++ ^= key;
  }
}

template <class ENTRY_T>
void process_toc(int fd, uint8_t* toc_buff, uint32_t entry_count) {
  ENTRY_T* entries = (ENTRY_T*) toc_buff;

  for (uint32_t i = 0; i < entry_count; i++) {
    uint32_t len  = entries[i].length;
    auto     buff = new uint8_t[len];
    lseek(fd, entries[i].offset, SEEK_SET);
    read(fd, buff, len);

    unrle0(buff, len);
    unzlc2(buff, len);

    as::write_file(entries[i].filename, buff, len);

    delete [] buff;
  }
}

int main(int argc, char** argv) {
  if (argc != 2) {
    fprintf(stderr, "extk2fpk v1.1 by asmodean\n\n");
    fprintf(stderr, "usage: %s <input.fpk>\n", argv[0]);   
    return -1;
  }

  string in_filename(argv[1]);

  int fd = as::open_or_die(in_filename, O_RDONLY | O_BINARY);

  FPKHDR hdr;
  read(fd, &hdr, sizeof(hdr));

  uint32_t entry_count = hdr.entry_count & ~0x80000000;
  uint32_t toc_len     = 0;
  uint8_t* toc_buff    = NULL;

  if (hdr.entry_count & 0x80000000) {
    FPKTRL trl;
    lseek(fd, -(int)sizeof(trl), SEEK_END);
    read(fd, &trl, sizeof(trl));

    toc_len  = ((sizeof(FPKENTRY1) * entry_count) + 3) & ~3;
    toc_buff = new uint8_t[toc_len];

    lseek(fd, trl.toc_offset, SEEK_SET);
    read(fd, toc_buff, toc_len);
    unobfuscate(toc_buff, toc_len, trl.key);
    process_toc<FPKENTRY1>(fd, toc_buff, entry_count);
  } else {
    toc_len  = sizeof(FPKENTRY2) * entry_count;
    toc_buff = new uint8_t[toc_len];

    read(fd, toc_buff, toc_len);
    process_toc<FPKENTRY2>(fd, toc_buff, entry_count);
  }

  delete [] toc_buff;

  close(fd);

  return 0;
}
