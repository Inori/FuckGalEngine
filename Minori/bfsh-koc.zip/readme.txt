
Please see comments in blowfish.c for license and usage information.
