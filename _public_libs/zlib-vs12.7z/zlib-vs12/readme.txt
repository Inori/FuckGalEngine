
 ZLIB Static Library
---------------------

When meet "error LNK2019: unresolved external symbol _inflateInit2_ ..."

Just change your code like this:

//
#define ZLIB_WINAPI
#include "zlib.h"
#undef ZLIB_WINAPI
//

Best wishes!
